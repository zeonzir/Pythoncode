#Function to convert temperature value to celsius from farenheit
def tempmrg(F):
	return((F-32)*5/9)