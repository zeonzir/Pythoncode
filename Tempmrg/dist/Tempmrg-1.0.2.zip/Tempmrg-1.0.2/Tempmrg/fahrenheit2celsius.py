def fahrenheitTocelsius(Fahrenheit):
	return ((int(Fahrenheit)-32)*5/9)
	