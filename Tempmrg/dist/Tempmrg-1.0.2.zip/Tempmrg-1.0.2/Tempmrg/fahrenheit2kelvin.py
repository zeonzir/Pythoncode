def fahrenheitTokelvin(Fahrenheit):
	return((int(Fahrenheit)+459.67)*5/9)
	